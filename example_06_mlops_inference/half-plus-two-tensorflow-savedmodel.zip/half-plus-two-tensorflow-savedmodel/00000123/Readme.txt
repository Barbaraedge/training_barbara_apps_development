# Query the model using the predict API
curl -d '{"instances": [1.0, 2.0, 5.0]}' \
    -X POST http://localhost:8501/v1/models/half_plus_two:predict


Ejecución en tritón:

Añadir a repositorio de modelos con la siguiente estructura:

halfplustwo/
	-config.pbtxt
	-1/
		-model.savedmodel/
			contenido carpeta modelo incluyendo saved_model.pb	

config.pbtxt:

name: "halfplustwo"
platform: "tensorflow_savedmodel"


docker run --rm -p8000:8000 -p8001:8001 -p8002:8002 -v path_local_repositorio_modelos:/models nvcr.io/nvidia/tritonserver:23.08-py3 tritonserver --model-repository=/models


Inferencia:


POST 127.0.0.1:8000/v2/models/halfplustwo/versions/1/infer

body: 

{
    "inputs": [
        {
            "name": "x",
            "datatype": "FP32",
            "shape" : [ 3, 1 ],
            "data": [ 1, 5, 8 ]
        }
    ]
}
